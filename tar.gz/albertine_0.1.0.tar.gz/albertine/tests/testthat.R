library(testthat)
library(albertine)

test_check("albertine")
